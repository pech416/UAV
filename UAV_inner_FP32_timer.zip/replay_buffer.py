import torch
import numpy as np

class ReplayBuffer(object):
    def __init__(self, args):
        self.N = args.N
        self.buffer_size = args.buffer_size
        self.batch_size = args.batch_size
        self.count = 0
        self.current_size = 0
        self.buffer_obs_n, self.buffer_a_n, self.buffer_r_n, self.buffer_s_next_n, self.buffer_done_n = [], [], [], [], []
        for agent_id in range(self.N):
            self.buffer_obs_n.append(np.empty((self.buffer_size, args.obs_dim_n[agent_id]), dtype=np.float32))
            self.buffer_a_n.append(np.empty((self.buffer_size, args.action_dim_n[agent_id]), dtype=np.float32))
            self.buffer_r_n.append(np.empty((self.buffer_size, 1), dtype=np.float32))
            self.buffer_s_next_n.append(np.empty((self.buffer_size, args.obs_dim_n[agent_id]), dtype=np.float32))
            self.buffer_done_n.append(np.empty((self.buffer_size, 1), dtype=np.float32))

    def store_transition(self, obs_n, a_n, r_n, obs_next_n, done_n):
        for agent_id in range(self.N):
            self.buffer_obs_n[agent_id][self.count] = obs_n[agent_id]
            self.buffer_a_n[agent_id][self.count] = a_n[agent_id]
            self.buffer_r_n[agent_id][self.count] = r_n[agent_id]
            self.buffer_s_next_n[agent_id][self.count] = obs_next_n[agent_id]
            self.buffer_done_n[agent_id][self.count] = done_n[agent_id]
        self.count = (self.count + 1) % self.buffer_size
        self.current_size = min(self.current_size + 1, self.buffer_size)

    def sample(self):
        index = np.random.choice(self.current_size, size=self.batch_size, replace=False)
        batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n = [], [], [], [], []
        # 优化: 使用 torch.from_numpy 直接构建张量，避免重复类型转换
        for agent_id in range(self.N):
            batch_obs_n.append(torch.from_numpy(self.buffer_obs_n[agent_id][index]))
            batch_a_n.append(torch.from_numpy(self.buffer_a_n[agent_id][index]))
            batch_r_n.append(torch.from_numpy(self.buffer_r_n[agent_id][index]))
            batch_obs_next_n.append(torch.from_numpy(self.buffer_s_next_n[agent_id][index]))
            batch_done_n.append(torch.from_numpy(self.buffer_done_n[agent_id][index]))
        return batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n
