import torch
import torch.nn.functional as F
import numpy as np
import copy
from networks import Actor, Critic_MADDPG

class MADDPG(object):
    def __init__(self, args, agent_id):
        self.N = args.N
        self.agent_id = agent_id
        self.max_action = args.max_action
        self.action_dim = args.action_dim_n[agent_id]
        self.lr_a = args.lr_a
        self.lr_c = args.lr_c
        self.gamma = args.gamma
        self.tau = args.tau
        self.use_grad_clip = args.use_grad_clip

        # 创建本 agent 的 actor 和 critic 网络
        self.actor = Actor(args, agent_id)
        self.critic = Critic_MADDPG(args)
        self.actor_target = copy.deepcopy(self.actor)
        self.critic_target = copy.deepcopy(self.critic)

        self.actor_optimizer = torch.optim.Adam(self.actor.parameters(), lr=self.lr_a)
        self.critic_optimizer = torch.optim.Adam(self.critic.parameters(), lr=self.lr_c)

    def choose_action(self, obs, noise_std):
        # 优化: 禁用梯度计算并使用 from_numpy 简化张量转换
        with torch.no_grad():
            if not isinstance(obs, np.ndarray):
                obs_np = np.array(obs, dtype=np.float32)
            else:
                obs_np = obs.astype(np.float32)
            obs_tensor = torch.from_numpy(obs_np).unsqueeze(0)
            a_tensor = self.actor(obs_tensor)
            a = a_tensor.cpu().numpy().flatten()
        noise = np.random.normal(0, noise_std, size=self.action_dim).astype(np.float32)
        a = (a + noise).clip(-self.max_action, self.max_action)
        return a

    def train(self, replay_buffer, agent_n, cached_actions=None):
        # 从经验回放池采样一个 batch
        batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n = replay_buffer.sample()
        # 计算所有 agent 的 target 动作（冻结当前策略输出）
        if cached_actions is None:
            with torch.no_grad():
                cached_actions = [agent.actor_target(batch_obs_next_n[i]).detach() for i, agent in enumerate(agent_n)]
        # Critic 网络更新
        with torch.no_grad():
            s_next_cat = torch.cat(batch_obs_next_n, dim=1)
            a_target_cat = torch.cat(cached_actions, dim=1)
            s_a_next = torch.cat([s_next_cat, a_target_cat], dim=1)
            Q_next = self.critic_target.forward_sa(s_a_next)
            target_Q = batch_r_n[self.agent_id] + self.gamma * (1 - batch_done_n[self.agent_id]) * Q_next
        s_cur_cat = torch.cat(batch_obs_n, dim=1)
        a_cur_cat = torch.cat(batch_a_n, dim=1)
        s_a_cur = torch.cat([s_cur_cat, a_cur_cat], dim=1)
        current_Q = self.critic.forward_sa(s_a_cur)
        critic_loss = F.mse_loss(target_Q, current_Q)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 10.0)
        self.critic_optimizer.step()
        # Actor 网络更新：仅更新当前 agent 的动作，其他 agent 使用缓存动作
        batch_a_n[self.agent_id] = self.actor(batch_obs_n[self.agent_id])
        s_cur_cat = torch.cat(batch_obs_n, dim=1)
        a_cur_cat = torch.cat(batch_a_n, dim=1)
        s_a_cur = torch.cat([s_cur_cat, a_cur_cat], dim=1)
        actor_loss = - self.critic.forward_sa(s_a_cur).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 10.0)
        self.actor_optimizer.step()
        # 软更新目标网络参数
        for param, target_param in zip(self.critic.parameters(), self.critic_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)

    def update_critic(self, replay_buffer, agent_n, cached_actions=None, batch_data=None):
        # 优化: 共享采样批次，避免每个智能体独立采样
        if batch_data is not None:
            batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n = batch_data
        else:
            batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n = replay_buffer.sample()
        if cached_actions is None:
            with torch.no_grad():
                cached_actions = [agent.actor_target(batch_obs_next_n[i]).detach() for i, agent in enumerate(agent_n)]
        with torch.no_grad():
            s_next_cat = torch.cat(batch_obs_next_n, dim=1)
            a_target_cat = torch.cat(cached_actions, dim=1)
            s_a_next = torch.cat([s_next_cat, a_target_cat], dim=1)
            Q_next = self.critic_target.forward_sa(s_a_next)
            target_Q = batch_r_n[self.agent_id] + self.gamma * (1 - batch_done_n[self.agent_id]) * Q_next
        s_cur_cat = torch.cat(batch_obs_n, dim=1)
        a_cur_cat = torch.cat(batch_a_n, dim=1)
        s_a_cur = torch.cat([s_cur_cat, a_cur_cat], dim=1)
        current_Q = self.critic.forward_sa(s_a_cur)
        critic_loss = F.mse_loss(target_Q, current_Q)
        self.critic_optimizer.zero_grad()
        critic_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.critic.parameters(), 10.0)
        self.critic_optimizer.step()
        return float(critic_loss.item())

    def update_actor(self, replay_buffer, agent_n, batch_data=None):
        # 优化: 预缓存公共输入张量，减少前向调用次数
        if batch_data is not None:
            batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n = batch_data
        else:
            batch_obs_n, batch_a_n, batch_r_n, batch_obs_next_n, batch_done_n = replay_buffer.sample()
        batch_a_n[self.agent_id] = self.actor(batch_obs_n[self.agent_id])
        s_cur_cat = torch.cat(batch_obs_n, dim=1)
        a_cur_cat = torch.cat(batch_a_n, dim=1)
        s_a_cur = torch.cat([s_cur_cat, a_cur_cat], dim=1)
        actor_loss = - self.critic.forward_sa(s_a_cur).mean()
        self.actor_optimizer.zero_grad()
        actor_loss.backward()
        if self.use_grad_clip:
            torch.nn.utils.clip_grad_norm_(self.actor.parameters(), 10.0)
        self.actor_optimizer.step()
        return float(actor_loss.item())

    def update_targets(self):
        # 软更新 actor 和 critic 的目标网络参数
        for param, target_param in zip(self.critic.parameters(), self.critic_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
        for param, target_param in zip(self.actor.parameters(), self.actor_target.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
